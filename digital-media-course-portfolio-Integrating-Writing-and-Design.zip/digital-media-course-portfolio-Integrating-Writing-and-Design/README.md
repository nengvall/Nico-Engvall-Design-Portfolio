# integrating-writing-and-design-portfolio

Digital Media Portfolio designed for pedagological considerations, built on Bootstrap. Using this template, students learn the basics of bootstrap including css standards and cool tools like modal views. 

This portfolio encourages students to oraganize and language their work to refine its presentation. Additionally, this portfolio requires students to argue how the work in the portfolio demonstrates their concerted effort to meet course goals. 

See step-by-step PDF instructions for mac or window platforms. 


